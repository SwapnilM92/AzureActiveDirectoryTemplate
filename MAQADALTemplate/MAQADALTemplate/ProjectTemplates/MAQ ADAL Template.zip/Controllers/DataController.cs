﻿#region Page Summary
/// *****************************************************************
///
/// Project:        LDPv2
/// Solution:       MAQ.LDP
///
/// Author:  MAQ Software
/// Date:    November 23, 2016
/// Description: Allows ADAL authentication and returns Get and Post messages.
///
/// Change History:
/// Name            Date                    Version        Description
/// -------------------------------------------------------------------------------
/// Developer    November 23, 2016          1.0.0.0        Allows ADAL authentication and returns Get and Post messages. 
/// -------------------------------------------------------------------------------
/// Copyright (C) MAQ Software
/// -------------------------------------------------------------------------------
#endregion

namespace $safeprojectname$
{

    #region Using
    using System.Web.Http;
    using System;
    #endregion
    /// <summary>
    /// This file is used to test the Get and Post controller.
    /// </summary>
    [Authorize]
    public class DataController : ApiController
    {

        ILogger logger = LoggerFactory.GetEventLogger;

        /// <summary>
        /// Returns an Get message
        /// </summary>
        [HttpGet]
        public IHttpActionResult Get()
        {
            logger.LogException(new ArgumentException(Constants.LOGGER_EVENT));
            return Ok<string>(Constants.GET_MESSAGE);
        }

        /// <summary>
        /// Returns a Post message
        /// </summary>
        [HttpPost]
        public IHttpActionResult Post()
        {
            return Ok<string>(Constants.POST_MESSAGE);
        }
    }
}
