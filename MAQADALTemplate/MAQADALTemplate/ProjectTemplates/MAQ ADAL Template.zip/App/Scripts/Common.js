﻿///<disable>JS2032, JS2074</disable>
// Function contains generic methods 
var oADALUserDataObject = (function () {
    "use strict";
    var commonConstants = {
        // Generic function for Ajax call to service controller
        callUserService: function (sWebMethodName, sServiceType, onSuccess, onFailure, sData) {
            "use strict";
            /// <disable>JS3058,JS2024</disable>
            /// <disable>DeclareVariablesBeforeUse,DoNotQuoteObjectLiteralPropertyNames</disable>
            /// <disable>JS3058.DeclareVariablesBeforeUse,JS2024.DoNotQuoteObjectLiteralPropertyNames</disable>
            var sWebMethodUrl = "api" + sWebMethodName;
            $.ajax({
                headers: { "authorization": "bearer " + oADALObject.getToken() },
                type: sServiceType,
                url: sWebMethodUrl,
                data: sData,
                processData: false,
                contentType: false,
                dataType: "JSON",
                // Handle successful result
                success: function (result) {
                    "use strict";
                    onSuccess(result);
                },
                // Handle failure result
                error: function (result) {
                    "use strict";
                    onFailure(oADALObject.getToken() == "" ? "Session has Expired" : result);
                }
            });
        },
    };
    // Return generic Ajax call to service controller function 
    return {
        callUserProvisionService: function (sWebMethodName, sServiceType, onSuccess, onFailure, sData) {
            "use strict";
            commonConstants.callUserService(sWebMethodName, sServiceType, onSuccess, onFailure, sData);
        }
    };
}());