﻿#region PageSummary
// *****************************************************************
// Project:        MAQWebService
// Solution:       WebApi
//
// Author:  MAQ Software
// Date:    November 17, 2016
// Description: Factory class implemented to wrap the Logger Interface
// Change History:
// Name                         Date                    Version        Description
// -------------------------------------------------------------------------------
// Developer               November 17, 2016           1.0.0.0       Logger Abstract class
// -------------------------------------------------------------------------------
// Copyright (C) MAQ Software
// -------------------------------------------------------------------------------
#endregion

namespace $safeprojectname$
{
    #region Using
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.Text;
    #endregion
    /// <summary>
    /// Logger abstract class for Exception and Message handling.
    /// </summary>
    public static class Logger
    {
        /// <summary>
        /// Writes the log message for specified exception.
        /// </summary>
        /// <param name="exception">Exception object</param>
        public static string GetFormattedExceptionString(Exception exception)
        {
            string returnString = String.Empty;
            if (null != exception)
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.AppendFormat(CultureInfo.InvariantCulture,
                                Constants.LOGGER_EXCEPTION_MESSAGE,
                                exception.Message,             //0
                                Environment.NewLine,           //1
                                exception.Source,              //2
                                exception.InnerException,      //3
                                exception.StackTrace           //4
                               );
                returnString = Convert.ToString(stringBuilder, CultureInfo.InvariantCulture);
                return returnString;
            }
            else
            {
                return returnString;
            }
        }
        /// <summary>
        /// Logs the specified error.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>
        public static string GetLogType(EventLogEntryType eventLogEntryType)
        {
            string type = Constants.LOG_LEVEL_INFO;
            switch (eventLogEntryType)
            {
                case EventLogEntryType.Error:
                    type = Constants.LOG_LEVEL_ERROR;
                    break;
                case EventLogEntryType.FailureAudit:
                    type = Constants.LOG_LEVEL_FAILURE_AUDIT;
                    break;
                case EventLogEntryType.SuccessAudit:
                    type = Constants.LOG_LEVEL_SUCCESS;
                    break;
                case EventLogEntryType.Warning:
                    type = Constants.LOG_LEVEL_WARNING;
                    break;
                case EventLogEntryType.Information:
                    type = Constants.LOG_LEVEL_INFO;
                    break;
                default:
                    type = Constants.LOG_LEVEL_INFO;
                    break;
            }
            return type;
        }
    }
}