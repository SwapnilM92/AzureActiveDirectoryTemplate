﻿#region PageSummary
// *****************************************************************
// Project:        MAQWebService
// Solution:       WebApi
//
// Author:  MAQ Software
// Date:    November 17, 2016
// Description: Class used to log all the errors on SQL Azure. 
// Change History:
// Name                         Date                    Version        Description
// -------------------------------------------------------------------------------
// Developer               November 17, 2016           1.0.0.0       Cloud based SQL Azure error logging mechanism.
// -------------------------------------------------------------------------------
// Copyright (C) MAQ Software
// -------------------------------------------------------------------------------
#endregion
namespace $safeprojectname$
{
    #region
    using Microsoft.WindowsAzure.Storage;
    using Microsoft.WindowsAzure.Storage.Table;
    using System;
    using System.Diagnostics;
    using System.Globalization;
    #endregion
    public class AzureLogger : ILogger
    {
        private string azureConnectionString = Constants.AZURE_CONNECTION;
        private CloudStorageAccount storageAccount;
        private CloudTableClient client;
        private CloudTable table;
        public AzureLogger()
        {
            azureConnectionString = Constants.AZURE_CONNECTION;
            storageAccount = CloudStorageAccount.Parse(azureConnectionString);
            client = storageAccount.CreateCloudTableClient();
            table = client.GetTableReference(Constants.ERROR_LOG_TABLE);
        }
        
        /// <summary>
        /// Logs the specified exception type error.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>
        public void LogException(Exception exception)
        {
            LoggerTypeException(Logger.GetFormattedExceptionString(exception), Logger.GetLogType(EventLogEntryType.Error));
        }

        /// <summary>
        /// Logs the specified information type error.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>
        public void LogInformation(string message, EventLogEntryType eventLogEntryType)
        {
            LoggerTypeException(message, Logger.GetLogType(EventLogEntryType.Information));
        }
        /// <summary>
        /// Logs the specified warning type error.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>
        public void LogWarning(string message, EventLogEntryType eventLogEntryType)
        {
            LoggerTypeException(message, Logger.GetLogType(EventLogEntryType.Warning));
        }

        /// <summary>
        /// This method logs error message to table or event viewer
        /// </summary>
        /// <param name="errorMessage">Error message to be logged</param>
        /// <param name="type">Event type of an Error</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>
        public void LoggerTypeException(string errorMessage, string type)
        {
            if (!string.IsNullOrWhiteSpace(errorMessage) && !string.IsNullOrWhiteSpace(type))
            {
                try
                {
                    table.CreateIfNotExists();
                    TableEntity tableEntityObj = new TableEntity();
                    tableEntityObj.PartitionKey = String.Concat(type, Constants.SEMICOLON, errorMessage);
                    string date = DateTime.Now.ToUniversalTime().ToString(Constants.AZURE_ROW_DATE_KEY_FORMAT, CultureInfo.InvariantCulture);
                    tableEntityObj.RowKey = string.Format(CultureInfo.InvariantCulture, Constants.PLACE_HOLDER, date, Guid.NewGuid());
                    TableOperation insertOp = TableOperation.Insert(tableEntityObj);
                    table.Execute(insertOp);
                }
                catch
                {
                    // Do nothing here
                }
                finally
                {
                    // Garbage collector
                    storageAccount = null;
                    client = null;
                }
            }
        }
    }
}