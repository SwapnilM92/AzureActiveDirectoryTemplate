﻿#region PageSummary
// *****************************************************************
// Project:        MAQWebService
// Solution:       WebApi
//
// Author:  MAQ Software
// Date:    November 17, 2016
// Description: Factory class implemented to wrap the Logger Interface
// Change History:
// Name                         Date                    Version        Description
// -------------------------------------------------------------------------------
// Developer               November 17, 2016           1.0.0.0       Factory class implemented to wrap the Logger Interface
// -------------------------------------------------------------------------------
// Copyright (C) MAQ Software
// -------------------------------------------------------------------------------
#endregion

namespace $safeprojectname$
{
    #region Using
    using System;
    #endregion
    /// <summary>
    /// Wrapper class for Logger
    /// </summary>
    public static class LoggerFactory
    {
        /// <summary>
        /// Gets the data for Azure logger
        /// </summary>
        /// <param name="exception">Most likely Exception thrown from the code</param>
        /// <returns>Logs the data/error in Azure database</returns>
        public static ILogger GetAzureLogger
        {
            get
            {
                return new AzureLogger();
            }
        }
        /// <summary>
        /// Gets the data for Event logger
        /// </summary>
        /// <param name="exception">Most likely Exception thrown from the code</param>
        /// <returns>Logs the error in event logger</returns>
        public static ILogger GetEventLogger
        {
            get
            {
                return new EventLogger();
            }
        }
    }
}