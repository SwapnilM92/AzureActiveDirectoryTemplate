﻿#region PageSummary
// *****************************************************************
// Project:        MAQWebService
// Solution:       WebApi
//
// Author:  MAQ Software
// Date:    November 17, 2016
// Description: Class used to log all the errors on SQL Azure. 
// Change History:
// Name                         Date                    Version        Description
// -------------------------------------------------------------------------------
// Developer               November 17, 2016           1.0.0.0       Event based error logging mechanism.
// -------------------------------------------------------------------------------
// Copyright (C) MAQ Software
// -------------------------------------------------------------------------------
#endregion
namespace $safeprojectname$
{
    #region Using
    using System;
    using System.Diagnostics;
    #endregion
    public class EventLogger : ILogger
    {
        public EventLogger()
        {
        }
        /// <summary>
        /// Logs the specified exception type error.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>
        public void LogException(Exception exception)
        {
            LogEventTypeException(Logger.GetFormattedExceptionString(exception), EventLogEntryType.Error);
        }

        /// <summary>
        /// Logs the specified information type error.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>        
        public void LogInformation(string message, EventLogEntryType eventLogEntryType)
        {
            LogEventTypeException(message, eventLogEntryType);
        }
        /// <summary>
        /// Logs the specified warning type error.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>
        public void LogWarning(string message, EventLogEntryType eventLogEntryType)
        {
            LogEventTypeException(message, eventLogEntryType);
        }

        /// <summary>
        /// This method logs error message to table or event viewer
        /// </summary>
        /// <param name="errorMessage">Error message to be logged</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>
        public void LogEventTypeException(string errorMessage, EventLogEntryType eventLogEntryType)
        {
            EventLog eventLog = new EventLog();
            try
            {
                if (!string.IsNullOrWhiteSpace(errorMessage))
                {
                    if (!EventLog.SourceExists(Constants.EVENT_SOURCE))
                    {
                        EventLog.CreateEventSource(Constants.EVENT_SOURCE, Constants.EVENT_LOG);
                    }
                    // Setting the source
                    eventLog.Source = Constants.EVENT_SOURCE;
                    // Write an entry to the event log.
                    eventLog.WriteEntry(errorMessage, eventLogEntryType, Constants.EVENT_ID);
                }
            }
            finally
            {
                eventLog.Close();
            }
        }
    }
}