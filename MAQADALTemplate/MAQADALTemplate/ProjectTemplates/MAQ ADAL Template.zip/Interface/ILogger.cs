﻿#region PageSummary
// *****************************************************************
// Project:        MAQWebService
// Solution:       WebApi
//
// Author:  MAQ Software
// Date:    November 17, 2016
// Description: Interface created for Logger
// Change History:
// Name                         Date                    Version        Description
// -------------------------------------------------------------------------------
// Developer               November 17, 2016           1.0.0.0       Class used to log all the errors occurred during runtime. 
// -------------------------------------------------------------------------------
// Copyright (C) MAQ Software
// -------------------------------------------------------------------------------
#endregion

using System;
using System.Diagnostics;

namespace $safeprojectname$
{
    /// <summary>
    /// Logger Interface
    /// </summary>
    public interface ILogger
    {
        /// <summary>
        /// Writes the log message for specified exception.
        /// </summary>
        /// <param name="exception">Exception object</param>
        void LogException(Exception exception);
        /// <summary>
        /// Logs the specified error.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>
        void LogInformation(string message, EventLogEntryType eventLogEntryType);
        /// <summary>
        /// Logs the specified warning.
        /// </summary>
        /// <param name="message">Message received to log an error.</param>
        /// <param name="eventLogEntryType">Type of the event log entry</param>
        void LogWarning(string message, EventLogEntryType eventLogEntryType);
    }
}
