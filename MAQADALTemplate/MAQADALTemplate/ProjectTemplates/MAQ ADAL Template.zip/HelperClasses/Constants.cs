﻿#region Page Summary
/// *****************************************************************
///
/// Project:        LDPv2
/// Solution:       MAQ.LDP
///
/// Author:  MAQ Software
/// Date:    December 01, 2016
/// Description: A class used to declare all the constants value.
///
/// Change History:
/// Name            Date                    Version        Description
/// -------------------------------------------------------------------------------
/// Developer    December 01, 2016          1.0.0.0       A class used to declare all the constants value.
/// -------------------------------------------------------------------------------
/// Copyright (C) MAQ Software
/// -------------------------------------------------------------------------------
#endregion

namespace $safeprojectname$
{

    #region Using
    using System;
    using System.Configuration;
    using System.Globalization;
    #endregion
    internal static class Constants
    {

        /// <summary>
        /// Display message on Get Method
        /// </summary>
        internal const string GET_MESSAGE = "You requested a Get Message";
        /// <summary>
        /// Display message on Post Method
        /// </summary>
        internal const string POST_MESSAGE = "You requested a Post Message";

        /// <summary>
        /// String Semi colon
        /// </summary>
        internal const string SEMICOLON = ";";

        #region Azure Logger
        /// <summary>
        ///  Date Key format used for exception logging
        /// </summary>
        internal const string AZURE_ROW_DATE_KEY_FORMAT = "MM-dd-yyyy HH:mm:ss:fffffff";

        /// <summary>
        /// Provides connection string for Azure connection.
        /// </summary>
        internal static readonly string AZURE_CONNECTION = ConfigurationManager.AppSettings["AzureConnection"];

        /// <summary>
        /// Provides the name of table to be used to log error on Azure SQL database
        /// </summary>
        internal static readonly string ERROR_LOG_TABLE = ConfigurationManager.AppSettings["ErrorLogTable"];
        #endregion

        #region EventLogger
        /// <summary>
        /// Contains the name for Event Logger file
        /// </summary>
        internal static readonly string EVENT_SOURCE = ConfigurationManager.AppSettings["EventSource"];

        /// <summary>
        /// Contains the name for Event Logger file
        /// </summary>
        internal static readonly string EVENT_LOG = ConfigurationManager.AppSettings["EventLog"];

        /// <summary>
        /// Application defined event identifier for event log
        /// </summary>
        internal static readonly int EVENT_ID = Convert.ToInt32(ConfigurationManager.AppSettings["EventId"], CultureInfo.InvariantCulture);
        #endregion

        #region Error Configurations
        /// <summary>
        ///  String literal for Log level Error
        /// </summary>
        internal const string LOG_LEVEL_ERROR = "Error";

        /// <summary>
        ///  String literal for Log level FailureAudit
        /// </summary>
        internal const string LOG_LEVEL_FAILURE_AUDIT = "FailureAudit";

        /// <summary>
        ///  String literal for Log level Success
        /// </summary>
        internal const string LOG_LEVEL_SUCCESS = "Success";

        /// <summary>
        ///  String literal for Log level Warning
        /// </summary>
        internal const string LOG_LEVEL_WARNING = "Warning";

        /// <summary>
        ///  String literal for Log level INFO
        /// </summary>
        internal const string LOG_LEVEL_INFO = "INFO";

        /// <summary>
        /// Consist of Exception Message 
        /// </summary>
        internal const string LOGGER_EXCEPTION_MESSAGE = "Exception Message: {0}.{1}Exception Source: {2}.{1}Exception Inner Exception: {3}.{1}Exception Stack: {4};";

        /// <summary>
        /// String Place holders
        /// </summary>
        internal const string PLACE_HOLDER = "{0} - {1}";
        #endregion

        #region Loggers
        /// <summary>
        /// Use Azure Logger.
        /// </summary>
        internal const string LOGGER_AZURE = "Azure";

        /// <summary>
        /// Use Event Logger.
        /// </summary>
        internal const string LOGGER_EVENT = "Event";
        #endregion

        #region Azure Application details
        internal static readonly string AUDIENCE = ConfigurationManager.AppSettings["ida:Audience"];
        internal static readonly string TENANT = ConfigurationManager.AppSettings["ida:Tenant"];
        #endregion
    }
}